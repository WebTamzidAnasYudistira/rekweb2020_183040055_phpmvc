<?php

class User_model
{
    private $nama = 'SubastianSk';

    public function getUser()
    {
        return $this->nama;
    }
}
