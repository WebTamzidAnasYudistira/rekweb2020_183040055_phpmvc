<?php

class User_model
{
    private $nama = 'Tamzid Anas Yudistira';

    public function getUser()
    {
        return $this->nama;
    }
}
